package pe.edu.upc.StartupElec.business.crud;

import java.util.List;

import pe.edu.upc.StartupElec.model.entity.Service;

public interface ServiceService extends CrudService<Service, Integer>{
	List<Service> findByName(Integer name) throws Exception;
}
