package pe.edu.upc.StartupElec.controller;

import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import pe.edu.upc.StartupElec.business.crud.CrudService;
import pe.edu.upc.StartupElec.business.crud.CustomerService;
import pe.edu.upc.StartupElec.model.entity.Customer;
/*import pe.edu.upc.StartupElec.model.entity.Service;*/

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Named("customerView")
@ViewScoped
public class CustomerView implements Serializable, EntityView<Customer, Integer> {
	
	private static final long serialVersionUID = 1L;

	private List<Customer> entities;
	private Customer entitySelected;
	private List<Customer> entitiesSelected;
	private Customer entitySearch;
	
	@Inject
	private CustomerService entityService;
	
	@PostConstruct
	public void init() {
		this.entitiesSelected = new ArrayList<>();
		this.entitySearch = new Customer();
		getAllEntities();
	}
	
	@Override
	public CrudService<Customer, Integer> getCrudService() {
		return this.entityService;
	}

	@Override
	public void createNew() {
		this.entitySelected=new Customer();
		/*
		this.entitySelected.setServece(new Service());*/
	}

	@Override
	public Integer getIdFromEntitySelected() {
		return this.entitySelected.getCustomer_id();
	}

	@Override
	public void searchEntity() {
		try {	// Modificar de acuerdo al atributo a buscar
			this.entities = this.entityService.search(this.entitySearch.getCustomer_lastname());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public List<Customer> getEntities() {
		return entities;
	}

	public void setEntities(List<Customer> entities) {
		this.entities = entities;
	}

	public Customer getEntitySelected() {
		return entitySelected;
	}

	public void setEntitySelected(Customer entitySelected) {
		this.entitySelected = entitySelected;
	}

	public List<Customer> getEntitiesSelected() {
		return entitiesSelected;
	}

	public void setEntitiesSelected(List<Customer> entitiesSelected) {
		this.entitiesSelected = entitiesSelected;
	}

	public Customer getEntitySearch() {
		return entitySearch;
	}

	public void setEntitySearch(Customer entitySearch) {
		this.entitySearch = entitySearch;
	}

	public CustomerService getEntityService() {
		return entityService;
	}

	public void setEntityService(CustomerService entityService) {
		this.entityService = entityService;
	}

}
