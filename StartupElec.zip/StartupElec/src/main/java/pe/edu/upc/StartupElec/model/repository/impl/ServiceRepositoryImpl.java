package pe.edu.upc.StartupElec.model.repository.impl;

import java.util.List;
import java.util.Optional;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import pe.edu.upc.StartupElec.model.entity.Service;
import pe.edu.upc.StartupElec.model.repository.ServiceRepository;

@Named
@ApplicationScoped
public class ServiceRepositoryImpl implements ServiceRepository{

	@PersistenceContext(unitName = "StartupElecPU")
	private EntityManager entityManager;
	
	@Override
	public EntityManager getEntityManager() {
		return this.entityManager;
	}

	@Override
	public Optional<Service> findById(Integer id) throws Exception {
		return this.findById(id, Service.class);
	}

	@Override
	public List<Service> findAll() throws Exception {
		String jpql="SELECT servece FROM Service servece";
		return this.findByQuery(Service.class, jpql);
	}

	@Override
	public List<Service> findByName(Integer name) throws Exception {
		String jpql="SELECT servece FROM Service servece WHERE service.name = '" + name + "'";
		return this.findByQuery(Service.class, jpql);
	}

	@Override
	public List<Service> findByData(String data) throws Exception {
		String jpql = "SELECT customer FROM Service service WHERE service.name LIKE '%" + data + "%'";
		return this.findByQuery(Service.class, jpql);
	}

}
