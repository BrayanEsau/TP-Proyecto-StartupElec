package pe.edu.upc.StartupElec.model.repository;

import java.util.List;

import pe.edu.upc.StartupElec.model.entity.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Integer> {
	List<Customer> findByDniAndLastName(Integer customer_dni, String customer_lastname ) throws Exception;
}
