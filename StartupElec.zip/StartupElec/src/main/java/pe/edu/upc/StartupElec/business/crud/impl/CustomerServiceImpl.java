package pe.edu.upc.StartupElec.business.crud.impl;

import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.inject.Named;

import pe.edu.upc.StartupElec.business.crud.CustomerService;
import pe.edu.upc.StartupElec.model.entity.Customer;
import pe.edu.upc.StartupElec.model.repository.CustomerRepository;
import pe.edu.upc.StartupElec.model.repository.JpaRepository;

@Named
@ApplicationScoped
public class CustomerServiceImpl implements CustomerService{

	@Inject
	private CustomerRepository customerRepository;
	
	@Override
	public JpaRepository<Customer, Integer> getJpaRepository() {
		return this.customerRepository;
	}

	@Override
	public List<Customer> findByDniAndLastName(Integer dni, String lastname) throws Exception {
		return this.customerRepository.findByDniAndLastName(dni, lastname);
	}

}
