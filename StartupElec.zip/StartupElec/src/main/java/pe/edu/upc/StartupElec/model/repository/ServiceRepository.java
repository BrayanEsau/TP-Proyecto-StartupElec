package pe.edu.upc.StartupElec.model.repository;

import java.util.List;

import pe.edu.upc.StartupElec.model.entity.Service;

public interface ServiceRepository extends JpaRepository<Service, Integer>{
	List<Service> findByName(Integer name) throws Exception;
}
