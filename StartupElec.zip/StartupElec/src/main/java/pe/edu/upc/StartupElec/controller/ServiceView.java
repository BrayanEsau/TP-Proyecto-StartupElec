package pe.edu.upc.StartupElec.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import pe.edu.upc.StartupElec.business.crud.CrudService;
import pe.edu.upc.StartupElec.business.crud.ServiceService;
import pe.edu.upc.StartupElec.model.entity.Service;

@Named("serviceView")
@ViewScoped
public class ServiceView implements Serializable, EntityView<Service, Integer>{

	private static final long serialVersionUID = 1L;

	private List<Service> entities;
	private Service entitySelected;
	private List<Service> entitiesSelected;
	private Service entitySearch;
	
	@Inject
	private ServiceService entityService;
	
	@PostConstruct
	public void init() {
		this.entitiesSelected = new ArrayList<>();
		this.entitySearch = new Service();
		getAllEntities();
	}
	
	@Override
	public CrudService<Service, Integer> getCrudService() {
		return this.entityService;
	}

	@Override
	public void createNew() {
		this.entitySelected=new Service();
		
	}

	@Override
	public Integer getIdFromEntitySelected() {
		return this.entitySelected.getType_servece_id();
	}

	@Override
	public void searchEntity() {
		try {	// Modificar de acuerdo al atributo a buscar
			this.entities = this.entityService.search(this.entitySearch.getType_servece_name());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public List<Service> getEntities() {
		return entities;
	}

	public void setEntities(List<Service> entities) {
		this.entities = entities;
	}

	public Service getEntitySelected() {
		return entitySelected;
	}

	public void setEntitySelected(Service entitySelected) {
		this.entitySelected = entitySelected;
	}

	public List<Service> getEntitiesSelected() {
		return entitiesSelected;
	}

	public void setEntitiesSelected(List<Service> entitiesSelected) {
		this.entitiesSelected = entitiesSelected;
	}

	public Service getEntitySearch() {
		return entitySearch;
	}

	public void setEntitySearch(Service entitySearch) {
		this.entitySearch = entitySearch;
	}

	public ServiceService getEntityService() {
		return entityService;
	}

	public void setEntityService(ServiceService entityService) {
		this.entityService = entityService;
	}
	
}
