package pe.edu.upc.StartupElec.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
/*import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;*/
import javax.persistence.Table;

@Entity
@Table(name = "customer", 
indexes = {@Index(columnList = "customer_dni, customer_lastname ", name="customer_index_customer_dni_customer_lastname")})
public class Customer {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer customer_id;
	
	@Column(name = "customer_name", nullable = false, length = 50)
	private String customer_name;
	
	@Column(name = "customer_dni", nullable = false, length = 8)
	private String customer_dni;
	
	@Column(name = "customer_lastname", nullable = false, length = 50)
	private String customer_lastname;
	
	@Column(name = "customer_email", nullable = false, length = 50)
	private String customer_email;
	
	@Column(name = "customer_image", nullable = false, length = 500)
	private String customer_image;
	
	@Column(name = "customer_state", nullable = false)
	private boolean customer_state;
	
	/*
	@ManyToOne
	@JoinColumn(name="type_servece_id")
	private Service servece; //service_id*/

	public Integer getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(Integer customer_id) {
		this.customer_id = customer_id;
	}

	public String getCustomer_name() {
		return customer_name;
	}

	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}

	public String getCustomer_dni() {
		return customer_dni;
	}

	public void setCustomer_dni(String customer_dni) {
		this.customer_dni = customer_dni;
	}

	public String getCustomer_lastname() {
		return customer_lastname;
	}

	public void setCustomer_lastname(String customer_lastname) {
		this.customer_lastname = customer_lastname;
	}

	public String getCustomer_email() {
		return customer_email;
	}

	public void setCustomer_email(String customer_email) {
		this.customer_email = customer_email;
	}

	public String getCustomer_image() {
		return customer_image;
	}

	public void setCustomer_image(String customer_image) {
		this.customer_image = customer_image;
	}

	public boolean isCustomer_state() {
		return customer_state;
	}

	public void setCustomer_state(boolean customer_state) {
		this.customer_state = customer_state;
	}
/*
	public Service getServece() {
		return servece;
	}

	public void setServece(Service servece) {
		this.servece = servece;
	}*/

	
}
