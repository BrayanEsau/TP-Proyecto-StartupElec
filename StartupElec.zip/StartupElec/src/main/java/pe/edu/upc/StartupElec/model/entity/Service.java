package pe.edu.upc.StartupElec.model.entity;

/*import java.util.ArrayList;
import java.util.List;*/
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
/*import javax.persistence.OneToMany;*/
import javax.persistence.Table;

@Entity
@Table(name = "service",indexes = {@Index(columnList = "type_servece_name",name = "service_index_name")})
public class Service {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer type_servece_id;
	
	@Column(name = "type_servece_name", nullable = false, length = 50)
	private String type_servece_name;
	
	@Column(name = "type_servece_description", nullable = false, length = 50)
	private String type_servece_description;
	
	@Column(name = "type_servece_state", nullable = false)
	private boolean type_servece_state;
	
	@Column(name = "customers_customer_id", nullable = true)
	private int customers_customer_id;
	
	@Column(name = "typeCards_type_card_id", nullable = false)
	private int typeCards_type_card_id;
	
	/*
	@OneToMany(mappedBy="servece")
	private List<Customer> customers;*/

	public Service() {
		//customers = new ArrayList<>();
	}

	public Integer getType_servece_id() {
		return type_servece_id;
	}

	public void setType_servece_id(Integer type_servece_id) {
		this.type_servece_id = type_servece_id;
	}

	public String getType_servece_name() {
		return type_servece_name;
	}

	public void setType_servece_name(String type_servece_name) {
		this.type_servece_name = type_servece_name;
	}

	public String getType_servece_description() {
		return type_servece_description;
	}

	public void setType_servece_description(String type_servece_description) {
		this.type_servece_description = type_servece_description;
	}

	public boolean isType_servece_state() {
		return type_servece_state;
	}

	public void setType_servece_state(boolean type_servece_state) {
		this.type_servece_state = type_servece_state;
	}

	public int getCustomers_customer_id() {
		return customers_customer_id;
	}

	public void setCustomers_customer_id(int customers_customer_id) {
		this.customers_customer_id = customers_customer_id;
	}

	public int getTypeCards_type_card_id() {
		return typeCards_type_card_id;
	}

	public void setTypeCards_type_card_id(int typeCards_type_card_id) {
		this.typeCards_type_card_id = typeCards_type_card_id;
	}

	/*
	public List<Customer> getCustomers() {
		return customers;
	}

	public void setCustomers(List<Customer> customers) {
		this.customers = customers;
	}*/

}
