package pe.edu.upc.StartupElec.model.repository.impl;

import java.util.List;
import java.util.Optional;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import pe.edu.upc.StartupElec.model.entity.Customer;
import pe.edu.upc.StartupElec.model.repository.CustomerRepository;

@Named     //CustomerRepositoryImpl customerRepositoryImpl = new CustomerRepositoryImpl();
@ApplicationScoped
public class CustomerRepositoryImpl implements CustomerRepository{

	@PersistenceContext(unitName = "StartupElecPU")
	private EntityManager entityManager;
	
	@Override
	public EntityManager getEntityManager() {
		return this.entityManager;
	}

	@Override
	public Optional<Customer> findById(Integer id) throws Exception {
		return this.findById(id, Customer.class);
	}

	@Override
	public List<Customer> findAll() throws Exception {
		String jpql="SELECT customer FROM Customer customer";
		return this.findByQuery(Customer.class, jpql);
	}

	@Override
	public List<Customer> findByDniAndLastName(Integer dni, String customer_lastname) throws Exception {
		String jpql="SELECT customer FROM Customer customer WHERE customer.customer_dni='"+ dni +"' and customer.customer_lastname='"+ customer_lastname +"' ";
		return this.findByQuery(Customer.class, jpql);
	}
	@Override
	public List<Customer> findByData(String data) throws Exception {
		String jpql = "SELECT customer FROM Customer customer WHERE customer.customer_lastname LIKE '%" + data + "%'";
		return this.findByQuery(Customer.class, jpql);
	}
}
