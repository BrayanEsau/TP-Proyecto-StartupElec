package pe.edu.upc.StartupElec.business.crud.impl;

import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.inject.Named;

import pe.edu.upc.StartupElec.business.crud.ServiceService;
import pe.edu.upc.StartupElec.model.entity.Service;
import pe.edu.upc.StartupElec.model.repository.JpaRepository;
import pe.edu.upc.StartupElec.model.repository.ServiceRepository;

@Named
@ApplicationScoped
public class ServiceServiceImpl implements ServiceService{

	@Inject
	private ServiceRepository serviceRepository;
	@Override
	public JpaRepository<Service, Integer> getJpaRepository() {
		return this.serviceRepository;
	}

	@Override
	public List<Service> findByName(Integer name) throws Exception {
		return this.serviceRepository.findByName(name);
	}

}
