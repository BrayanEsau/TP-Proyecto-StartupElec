package pe.edu.upc.StartupElec.business.crud;

import java.util.List;

import pe.edu.upc.StartupElec.model.entity.Customer;

public interface CustomerService extends CrudService<Customer, Integer>{
	List<Customer> findByDniAndLastName(Integer dni, String lastname ) throws Exception;
}
